<template>
  <div id="app">
    <!-- <p>
      <router-link to="/newslist">新闻列表</router-link>&nbsp;
      <router-link to="/foodlist">食品列表</router-link>
    </p> -->
    <router-view></router-view>
  </div>
</template>
