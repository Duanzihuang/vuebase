<template>
  <div>
    <ul>
      <li>
        <router-link to="/newsdetail?id=1001"
          >俄罗斯梁赞州军火库发生爆炸</router-link
        >
      </li>
      <li>王一博摔车官方仲裁</li>
      <li>
        <router-link to="/newsdetail/1003"
          >刷屏了！中国最大金矿63岁董事长娶38岁妻子，新娘：相信爱情</router-link
        >
      </li>
    </ul>
  </div>
</template>
