<template>
  <div>
    菜单2要展示的组件
  </div>
</template>
