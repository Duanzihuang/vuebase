<template>
  <ul>
    <li>特朗普战胜了新冠</li>
    <li>亚美尼亚和阿塞拜疆开战了</li>
    <li>解放军空军飞抵台湾海峡</li>
  </ul>
</template>
