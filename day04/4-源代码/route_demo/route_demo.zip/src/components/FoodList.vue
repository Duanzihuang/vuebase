<template>
  <ul>
    <li>光明乳鸽</li>
    <li>潮汕撒尿牛丸</li>
    <li>猪脚饭</li>
  </ul>
</template>
